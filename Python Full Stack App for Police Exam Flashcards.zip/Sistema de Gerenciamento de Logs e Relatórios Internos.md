# Sistema de Gerenciamento de Logs e Relatórios Internos

## 📋 Descrição

Aplicação Streamlit camuflada como sistema corporativo de gerenciamento de logs, desenvolvida para estudo de Direito Penal focado em concursos para Agente de Trânsito (bancas Fundatec e Fepese).

## 🎯 Características

- **100 questões** estilo flashcard sobre Direito Penal
- **Temas focados**: Crimes contra a Administração Pública, Crimes contra a Fé Pública e Abuso de Autoridade
- **Interface camuflada**: Design corporativo discreto (cinza, branco e azul marinho)
- **Estilo Fundatec/Fepese**: Foco na literalidade da lei e situações práticas de trânsito
- **Filtros por categoria**: Simula filtros de departamento e período
- **Persistência de estado**: Questões não mudam ao revelar resposta

## 📂 Estrutura do Projeto

```
/home/ubuntu/
├── app.py                          # Aplicação Streamlit principal
├── questoes_direito_penal.py       # Base de dados com 100 questões
├── analise_pdf.txt                 # Análise do PDF fonte
└── README.md                       # Este arquivo
```

## 🚀 Como Usar

### 1. Instalação Local

```bash
# Instalar dependências
pip install streamlit

# Executar a aplicação
streamlit run app.py
```

### 2. Deploy no Streamlit Cloud

1. Faça upload do arquivo `app.py` para um repositório GitHub
2. Acesse [share.streamlit.io](https://share.streamlit.io)
3. Conecte seu repositório GitHub
4. Selecione o arquivo `app.py` como main file
5. Clique em "Deploy"

### 3. Deploy no GitHub

```bash
# Inicializar repositório
git init
git add app.py
git commit -m "Initial commit: Sistema de Gerenciamento de Logs"

# Conectar ao GitHub (substitua pelo seu repositório)
git remote add origin https://github.com/seu-usuario/seu-repositorio.git
git branch -M main
git push -u origin main
```

## 🎨 Interface

### Camuflagem Profissional

- **Título**: "Sistema de Gerenciamento de Logs e Relatórios Internos"
- **Terminologia**:
  - "ID do Registro" (ao invés de "Pergunta")
  - "Detalhes do Log" (ao invés de "Resposta")
  - "Próximo Registro" (ao invés de "Próxima Questão")
  - "Verificar Status" (ao invés de "Ver Resposta")
  - "Departamento" (ao invés de "Categoria")

### Funcionalidades

1. **Próximo Registro**: Gera uma nova questão aleatória
2. **Verificar Status**: Revela a resposta da questão atual
3. **Filtros na Sidebar**:
   - Departamento (filtra por categoria de crime)
   - Período do Relatório (apenas visual)
4. **Estatísticas**:
   - Total de Registros
   - Registros Filtrados
   - Consultas Realizadas

## 📊 Categorias de Questões

1. **Crimes contra a Fé Pública** (17 questões)
   - Falsificação de documentos
   - Uso de documento falso
   - Adulteração de veículo
   - Falsa identidade

2. **Crimes contra a Administração Pública** (55 questões)
   - Peculato
   - Concussão e Corrupção
   - Prevaricação
   - Resistência, Desobediência e Desacato
   - Descaminho e Contrabando
   - Denunciação Caluniosa

3. **Situações Práticas** (14 questões)
   - Casos reais de abordagem de trânsito
   - Aplicação prática dos conceitos

4. **Conceitos Fundamentais** (5 questões)
   - Definições legais
   - Funcionário público para fins penais

5. **Penas e Agravantes** (5 questões)
   - Comparação de penas
   - Causas de aumento

6. **Abuso de Autoridade** (4 questões)
   - Lei 13.869/2019

## 🔒 Segurança e Privacidade

- Nenhum dado pessoal é coletado
- Todas as questões estão embutidas no código
- Não há conexão com banco de dados externo
- Session state local (não persistente entre sessões)

## 📝 Notas Importantes

- As questões foram elaboradas com base no PDF "02-DireitoPenal-1666133528918.pdf"
- Foco em temas relevantes para concursos de Agente de Trânsito
- Estilo de questões baseado nas bancas Fundatec e Fepese
- Interface discreta para uso em ambientes corporativos

## 🛠️ Tecnologias Utilizadas

- **Python 3.11**
- **Streamlit** (framework web)
- **HTML/CSS** (customização de interface)

## 📄 Licença

Código desenvolvido para fins educacionais.

## 👨‍💻 Autor

Desenvolvido como ferramenta de estudo para concursos policiais.

---

**Versão**: 2.1.4  
**Data**: Janeiro 2025
